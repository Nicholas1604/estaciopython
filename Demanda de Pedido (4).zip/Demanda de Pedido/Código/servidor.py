from flask import Flask, render_template, jsonify
import requests
import pandas as pd

app = Flask(__name__)

# Dicionário de sabores de pizza
pizzas = {
    '35': ('Pizza Margherita', 35),
    '38': ('Pizza Calabresa', 38),
    '40': ('Pizza Portuguesa', 40)
}


@app.route('/')
def pizza_analytics():
    try:
        response = requests.get('http://localhost:5000/data')  # Ajuste o endereço conforme necessário
        pedidos = response.json()
    except requests.exceptions.RequestException as e:
        return f"Erro ao acessar dados: {str(e)}", 500

    df = pd.DataFrame(pedidos)
    df = df[df['status'] == 'pronto']

    # Mapeamento dos preços para os sabores
    df['sabor'] = df['preco'].map(lambda x: pizzas[str(x)][0])
    df['preco_unitario'] = df['preco'].map(lambda x: pizzas[str(x)][1])
    
    # Cálculo do faturamento total por sabor
    df['total_venda'] = df['preco_unitario'] * df['quantidade']
    faturamento_por_sabor = df.groupby('sabor')['total_venda'].sum()

    # Identificação do sabor mais e menos vendido com base no faturamento
    mais_vendido = faturamento_por_sabor.idxmax()
    menos_vendido = faturamento_por_sabor.idxmin()

    data = {
        'mais_vendido': mais_vendido,
        'menos_vendido': menos_vendido,
        'faturamento_mais': faturamento_por_sabor[mais_vendido],
        'faturamento_menos': faturamento_por_sabor[menos_vendido],
        'cliente_top': df['nome'].value_counts().idxmax() if not df['nome'].value_counts().empty else 'N/A'
    }

    return render_template('analytics.html', data=data)


if __name__ == '__main__':
    app.run(debug=True, port=5001)
